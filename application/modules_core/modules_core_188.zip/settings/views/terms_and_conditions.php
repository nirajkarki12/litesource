
<script src="//cdn.ckeditor.com/4.10.0/standard/ckeditor.js"></script>
<textarea class="" id="editor1" style="width: 100%;" name="terms_conditions">
       <?php echo $terms_conditions ?>
</textarea> 

<script>
    CKEDITOR.replace( 'editor1' );
</script>