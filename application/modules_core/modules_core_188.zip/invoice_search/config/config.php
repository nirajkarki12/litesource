<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

$config = array(
	'module_name'	=>	$this->lang->line('invoice_search'),
	'module_path'	=>	'invoice_search',
	'module_config'	=>	array()
);

?>