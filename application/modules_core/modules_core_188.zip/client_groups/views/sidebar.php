<div class="section_wrapper">

	<h3 class="title_white"><?php echo $this->lang->line('client_groups'); ?></h3>

	<ul class="quicklinks content toggle">
		<li><?php echo anchor('client_groups', $this->lang->line('view_client_groups')); ?></li>
		<li class="last"><?php echo anchor('client_groups/form', $this->lang->line('add_client_group')); ?></li>
	</ul>

</div>