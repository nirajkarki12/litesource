<div class="section_wrapper">

	<h3 class="title_white"><?php echo $this->lang->line('invoice_groups'); ?></h3>

	<ul class="quicklinks content toggle">
		<li><?php echo anchor('invoices/invoice_groups', $this->lang->line('view_invoice_groups')); ?></li>
		<li class="last"><?php echo anchor('invoices/invoice_groups/form', $this->lang->line('add_invoice_group')); ?></li>
	</ul>

</div>