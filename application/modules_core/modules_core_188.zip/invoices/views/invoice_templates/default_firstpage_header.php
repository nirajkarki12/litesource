<table class="header">
	<tr>
		
		<td>
            Unit 8, 69-73 O’Riordan Street&nbsp;|&nbsp;Alexandria NSW 2015&nbsp;|&nbsp;T +61 2 9669 6976&nbsp;|&nbsp;F +61 2 8079 6693
            <?php /*
			<?php echo $this->mdl_mcb_data->setting('tax_id_number_label') . ' ' . $user->tax_id_number; ?> &nbsp;|&nbsp; 
			<?php echo $user->address; ?>&nbsp;|&nbsp;
			<?php echo $user->city; ?>&nbsp;
			<?php echo $user->state; ?>&nbsp;
			<?php echo $user->zip; ?>&nbsp;|&nbsp;
			<?php echo $user->country; ?>&nbsp;|&nbsp;
			F <?php echo $user->fax_number; ?>
            */ ?>
		</td>
		<td><img width="150" src="<?php echo invoice_logo_file(); ?>" /></td>
	</tr>
</table>
