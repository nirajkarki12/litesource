<script type="text/javascript">
	$(function() {

		$('#password').val('');
		$('#passwordv').val('');

	});
</script>