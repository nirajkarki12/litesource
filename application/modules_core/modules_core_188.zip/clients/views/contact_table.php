<table style="width: 100%;">
	<tr>
		<th scope="col"><?php echo $this->lang->line('name'); ?></th>
		<th width="40%"scope="col"><?php echo $this->lang->line('email'); ?>
		<th width="14%"scope="col" class="last"><?php echo $this->lang->line('actions'); ?></th>
	</tr>
	<?php foreach ($contacts as $contact) { ?>
	<tr>
		<td class="first" nowrap="nowrap">
			<?php echo anchor('clients/contacts/details/client_id/' . $contact->client_id . '/contact_id/' . $contact->contact_id, $contact->contact_name, 'class="entity_'.$contact->contact_active.'"'); ?>
		</td>
		<td><?php echo $contact->email_address; ?></td>
		<td class="last">
			<a href="<?php echo site_url('clients/contacts/details/client_id/' . $contact->client_id . '/contact_id/' . $contact->contact_id); ?>" title="<?php echo $this->lang->line('view'); ?>">
				<?php echo icon('edit'); ?>
			</a>
			<?php if (!$this->mdl_mcb_data->setting('disable_delete_links')) { ?>
			<a href="<?php echo site_url('clients/contacts/delete/client_id/' . $contact->client_id . '/contact_id/' . $contact->contact_id); ?>" title="<?php echo $this->lang->line('delete'); ?>" onclick="javascript:if(!confirm('<?php echo $this->lang->line('confirm_delete'); ?>')) return false">
				<?php echo icon('delete'); ?>
			</a>
			<?php } ?>	
			

		</td>
	</tr>
	<?php } ?>
</table>