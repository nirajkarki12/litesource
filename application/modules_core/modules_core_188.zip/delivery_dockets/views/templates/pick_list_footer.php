<table class="footer">
	<tr>
		<td valign="bottom" style="text-align: right;"><span class="bold">Page {PAGENO}</span></td>
	</tr>
</table>