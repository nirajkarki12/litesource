



<div class="form-group">
    <label>Company Name:</label>
    <input type="text" name="company_name" value="<?= $banking_details->company_name ?>">
</div><br>

<div class="form-group">
    <label>ABN:</label>
    <input type="text" name="abn" value="<?= $banking_details->abn ?>">
</div><br>

<div class="form-group">
    <label>Bank BSB:</label>
    <input type="text" name="bank_rsb" value="<?= $banking_details->bank_rsb ?>">
</div><br>

<div class="form-group">
    <label>ACCT:</label>
    <input type="text" name="acct" value="<?= $banking_details->acct ?>">
</div><br>

<div class="form-group">
    <label>Swift Code:</label>
    <input type="text" name="swift_code" value="<?= $banking_details->swift_code ?>">
</div><br>



