<table class="header">
	<tr>
		
		<td>
            <?php echo $this->lang->line('pdf_header'); ?>
		</td>
	</tr>
</table>
