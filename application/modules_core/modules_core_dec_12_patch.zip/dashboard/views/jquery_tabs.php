<script type="text/javascript">
	$(function() {
		$("#tabs").tabs();
	});
</script>