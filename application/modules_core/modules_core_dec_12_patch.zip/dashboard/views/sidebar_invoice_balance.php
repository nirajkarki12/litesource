<div class="section_wrapper">

	<h3 class="title_black"><?php echo $this->lang->line('total_balance'); ?></h3>
	<h3 class="title_white"><?php echo display_currency($invoice_total_balance); ?></h3>

</div>