<div class="section_wrapper">

	<h3 class="title_white"><?php echo $this->lang->line('payments'); ?></h3>

	<ul class="quicklinks content toggle">
		<li><?php echo anchor('payments/index', $this->lang->line('view_payments')); ?></li>
		<li class="last"><?php echo anchor('payments/form', $this->lang->line('enter_payment')); ?></li>
	</ul>

</div>