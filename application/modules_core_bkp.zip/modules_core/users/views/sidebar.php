<div class="section_wrapper">

	<h3 class="title_white"><?php echo $this->lang->line('user_accounts'); ?></h3>

	<ul class="quicklinks content toggle">
		<li><?php echo anchor('users', $this->lang->line('view_user_accounts')); ?></li>
		<li class="last"><?php echo anchor('users/form', $this->lang->line('create_user_account')); ?></li>
	</ul>

</div>