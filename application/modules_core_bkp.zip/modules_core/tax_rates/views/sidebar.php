<div class="section_wrapper">

	<h3 class="title_white"><?php echo $this->lang->line('tax_rates'); ?></h3>

	<ul class="quicklinks content toggle">
		<li><?php echo anchor('tax_rates', $this->lang->line('view_tax_rates')); ?></li>
		<li class="last"><?php echo anchor('tax_rates/form', $this->lang->line('add_tax_rate')); ?></li>
	</ul>

</div>