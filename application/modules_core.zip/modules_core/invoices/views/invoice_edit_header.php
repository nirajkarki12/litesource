<style type="text/css">
.ui-tabs .ui-tabs-hide {
     display: none;
}
</style>