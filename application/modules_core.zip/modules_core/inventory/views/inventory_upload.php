<?php $this->load->view('dashboard/header'); ?>
<?php $this->load->view('dashboard/jquery_date_picker'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>


<div class="container_10" id="center_wrapper">
    <div class="grid_7" id="content_wrapper">

        <div class="section_wrapper">

            <h3 class="title_black"><?php echo $this->lang->line('export_inventory'); ?></h3>

            <?php $this->load->view('dashboard/system_messages'); ?>

            <div class="content toggle">
                <form method="post" action="<?php echo site_url($this->uri->uri_string()); ?>" >
                    <input type="hidden" name="type" value="0">
                     <dl>
                        <dt><label>Type</label></dt>
                        <dd><select name="type">
                                <option value="0">Parts</option>
                                <option value="1">Grouped Products</option>
                                <option value="all">All</option>
                            </select>
                        </dd>
                    </dl>
                    <dl>
                        <dt><label><?php echo $this->lang->line('changed_since_date'); ?>: </label></dt>
                        <dd><input class="datepicker" type="text" name="changed_since_date" value="" /></dd>
                    </dl>
                    <dl>
                        <dt><label><?php echo $this->lang->line('supplier_text'); ?>: </label></dt>
                        <dd>
                            <select name="supplier_list[]" class="supplier" id="supplier_multiselect" multiple="multiple">
                                <?php if(sizeof($suppliers) > 0): ?>
                                <?php foreach($suppliers as $supplier): ?>
                                <option value="<?php echo $supplier->client_id; ?>" ><?php echo $supplier->client_name; ?></option>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </dd>
                    </dl>
                    <dl>
                        <dt></dt>
                        <dd><label><input type="checkbox" id="export_include_archived" name="export_include_archived" value="1">Include Archived?</label></dd>
                    </dl>
                    <dl>
                        <dt></dt>
                        <dd><label><input type="checkbox" id="delete_inventories" name="delete_inventories" value="1">Delete inventories of selected suppliers</label></dd>
                    </dl>
                    <dl>
                        <dt><label>Sort By</label></dt>
                        <dd>
                            <select name="sort_by">
                                <option value="">Please Select</option>
                                <option value="sku">SKU</option>
                                <option value="supplier_name">Supplier</option>
                                <option value="name">Cat #</option>
                                <option value="category_name">Category</option>
                            </select>
                        </dd>
                    </dl>
                    <dl>
                        <dt><label>Sort Direction</label></dt>
                        <dd>
                            <select name="sort_order">
                                <option value="">Please Select</option>
                                <option value="asc">ASC</option>
                                <option value="desc">DESC</option>
                            </select>

                        </dd>
                    </dl>


                    <input type="submit" id="btn_submit" name="btn_export_inventory" class="del_inv" value="<?php echo $this->lang->line('export_inventory'); ?>" />
                    <input type="submit" id="btn_cancel" name="btn_cancel" value="<?php echo $this->lang->line('cancel'); ?>" />
                </form>

            </div>

        </div>



    </div>
</div>



<div class="container_10" id="center_wrapper">
    <div class="grid_7" id="content_wrapper">

        <div class="section_wrapper">

            <h3 class="title_black"><?php echo $this->lang->line('inventory_upload'); ?>
                <?php // $this->load->view('dashboard/btn_add', array('btn_name' => 'download_sample_import', 'btn_value' => 'Download Sample Import File')); ?>
            </h3>

            <?php $this->load->view('dashboard/system_messages'); ?>
            
            <?php if (isset($upload_error) and $upload_error) { ?>
                <div class="error"><?php echo $upload_error; ?></div>
            <?php } ?>
            
            <div class="content toggle">

                <form method="post" action="<?php echo site_url($this->uri->uri_string()); ?>" enctype="multipart/form-data">

                    <dl>
                        <dt><label><?php echo $this->lang->line('select_file'); ?>: </label></dt>
                        <dd><input type="file" name="userfile" size="20" /></dd>
                    </dl>
                    
                    <label>
                        <input type="checkbox" id="product_type" name="db_inventory_overwrite" value="1">Overwrite database(only parts)
                    </label>
                    
                    <label>
                        <input style="margin-left: 30%" type="checkbox" name="unaffect_qty" value="1">Maintain live stock counts
                    </label><br>
                    
                    <input type="submit" id="btn_submit" name="btn_upload_inventory" class="chk_inv_type"  value="<?php echo $this->lang->line('inventory_upload'); ?>" />
                    <input type="submit" id="btn_cancel" name="btn_cancel" value="<?php echo $this->lang->line('cancel'); ?>" />

                </form>

            </div>

        </div>

    </div>
</div>

<?php $this->load->view('dashboard/footer'); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $('#supplier_multiselect').select2();
    });
</script>

<script type="text/javascript">
    $(document).ready(function () {
        $('.chk_inv_type').on('click', function (e) {
            if (document.getElementById("product_type").checked == true) {
                if (!confirm('This will overwrite the database. Please ensure you have a backup. Are you sure you wish to continue?')) {
                    e.preventDefault();
                }
            }
        });
    });

    $(document).ready(function () {
        $('.del_inv').on('click', function (e) {
            if (document.getElementById("delete_inventories").checked == true) {
                if (!confirm('Are you sure you want to delete all inventories of the selected suppliers?')) {
                    e.preventDefault();
                }
            }
        });
    });
</script>