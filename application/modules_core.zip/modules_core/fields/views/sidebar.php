<div class="section_wrapper">

	<h3 class="title_white"><?php echo $this->lang->line('custom_fields'); ?></h3>

	<ul class="quicklinks content toggle">
		<li><?php echo anchor('fields', $this->lang->line('view_custom_fields')); ?></li>
		<li class="last"><?php echo anchor('fields/form', $this->lang->line('add_custom_field')); ?></li>
	</ul>

</div>