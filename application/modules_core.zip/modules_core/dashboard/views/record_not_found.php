<?php $this->load->view('dashboard/header'); ?>

<div class="grid_10" id="content_wrapper">

	<div class="section_wrapper">

		<h3 class="title_black"><?php echo $this->lang->line('record_does_not_exist'); ?></h3>

		<div class="content">

			<p><?php echo $this->lang->line('record_does_not_exist'); ?></p>

		</div>

	</div>

</div>

<?php $this->load->view('dashboard/footer'); ?>