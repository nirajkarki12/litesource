<script type="text/javascript">
	$(function() {

		$('#<?php echo $id; ?>').focus();

	});
</script>